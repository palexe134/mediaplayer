package com.viedo.mediaplayer.bean;

import android.database.Cursor;
import android.provider.MediaStore.Audio.Media;

import java.io.SequenceInputStream;
import java.io.Serializable;

/**
 * Created by palexe on 2017/3/30.
 */

public class MusicBean implements Serializable{
    public String data;
    public String musicname;
    public String musicartist;
    public String musicsize;
    public int musiduration;

    public static MusicBean getMusicBean(Cursor cursor){
        if(cursor!=null){
            MusicBean musicBean = new MusicBean();
            musicBean.data= cursor.getString(cursor.getColumnIndex(Media.DATA));
            musicBean.musicname=cursor.getString(cursor.getColumnIndex(Media.TITLE));
            musicBean.musicartist= cursor.getString(cursor.getColumnIndex(Media.ARTIST));
            musicBean.musicsize=cursor.getString(cursor.getColumnIndex(Media.SIZE));
            musicBean.musiduration= cursor.getInt(cursor.getColumnIndex(Media.DURATION));
            return musicBean;
        }
        return null;
    }


}
