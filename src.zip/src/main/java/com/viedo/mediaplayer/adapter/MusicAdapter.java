package com.viedo.mediaplayer.adapter;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import android.support.v4.widget.CursorAdapter;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.viedo.mediaplayer.R;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * Created by palexe on 2017/3/29.
 */

public class MusicAdapter extends CursorAdapter {
//    private String string;
    //    public MusicAdapter(Context context, Cursor c, boolean autoRequery) {
//        super(context, c, autoRequery);
//    }

    public MusicAdapter(Context context, Cursor c) {
        super(context, c, FLAG_REGISTER_CONTENT_OBSERVER);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = View.inflate(context, R.layout.vbang_item, null);

        ViewHolder viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        ViewHolder viewholder = (ViewHolder) view.getTag();
        viewholder.musicname.setText(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)));
        viewholder.musicartist.setText(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)));
        String s = Formatter.formatFileSize(context, cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)));
        viewholder.musicsize.setText(s);

    }

    class ViewHolder {


        @BindView(R.id.music_name)
        TextView musicname;
        @BindView(R.id.music_artist)
        TextView musicartist;
        @BindView(R.id.music_size)
        TextView musicsize;

        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
//            ButterKnife.bind(view);

        }
    }


}
