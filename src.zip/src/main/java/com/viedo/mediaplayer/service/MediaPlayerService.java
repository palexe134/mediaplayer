package com.viedo.mediaplayer.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;

import com.viedo.mediaplayer.bean.MusicBean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by palexe on 2017/4/8.
 */

public class MediaPlayerService extends Service {

    private MediaPlayer mediaPlayer;
    private int position=-1;
    private ArrayList<MusicBean> list;
    public static  final  int MODE_SINGLE = 0;
    public static  final  int MODE_RANDOM = 1;
    public static  final  int MODE_ORDER = 2;

    public static  int currentMode =2;

    public static final int PLAY_Mode_PRE = 100;
    public static final int PLAY_Mode_NEXT = 101;



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();
    }
    public class MyBinder extends Binder{
        public void playPause(){
            if(mediaPlayer!=null&&mediaPlayer.isPlaying()){
                mediaPlayer.pause();
                sendBroadcast(new Intent("pause.play"));
            }else{
                mediaPlayer.start();
                notifyPlayerUpdateUi();
            }
        }
        public MusicBean getCurrentMusic(){
            return list.get(position);
        }

        public boolean isPlaying(){
            return mediaPlayer.isPlaying();
        }
        public int getCurrntDuration(){
            //获取播放的时长
            return  mediaPlayer.getCurrentPosition();
        }
        public void seekTo(int position){
            mediaPlayer.seekTo(position);
        }
        public void preOrNext(int mode){
            switch (currentMode){
                case MODE_RANDOM:
                    Random random = new Random();
                    int temp_position = random.nextInt(list.size());
                    while (temp_position==position){
                        temp_position = random.nextInt(list.size());
                    }
                    position = temp_position;

                    break;
                case MODE_ORDER:
                   if(mode == PLAY_Mode_PRE){
                       position = position==0?list.size()-1:--position;

                   }else if(mode == PLAY_Mode_NEXT){
//                       记住算法要算好
                       position = ++position%list.size();
                   }
                    break;
            }
            playMusic();
        }


    }


    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }
    //此方式可以多次开启

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        list = (ArrayList<MusicBean>) intent.getSerializableExtra("list");

        int temp = intent.getIntExtra("position", 0);
        if(temp==position){
            notifyPlayerUpdateUi();
        }else{
            position =temp;
            playMusic();

        }




        return super.onStartCommand(intent, flags, startId);
    }

    private void playMusic() {
        if(mediaPlayer==null) {
            mediaPlayer = new MediaPlayer();
        }else{
            mediaPlayer.reset();
        }
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mediaPlayer.start();
                notifyPlayerUpdateUi();
            }
        });
        try {
            mediaPlayer.setDataSource(list.get(position).data);
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void notifyPlayerUpdateUi() {
        sendBroadcast(new Intent("com.mediaplayer.service"));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
