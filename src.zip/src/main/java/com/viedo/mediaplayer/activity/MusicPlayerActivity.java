package com.viedo.mediaplayer.activity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.viedo.mediaplayer.R;
import com.viedo.mediaplayer.bean.MusicBean;
import com.viedo.mediaplayer.service.MediaPlayerService;
import com.viedo.mediaplayer.utils.utils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by palexe on 2017/4/4.
 */

public class MusicPlayerActivity extends AppCompatActivity {
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_artist)
    TextView tvArtist;
    @BindView(R.id.rl_top)
    RelativeLayout rlTop;
    @BindView(R.id.iv_wave)
    ImageView ivWave;
    @BindView(R.id.tv_time)
    TextView tvTime;
    @BindView(R.id.sb_progress)
    SeekBar sbProgress;
    @BindView(R.id.iv_playmode)
    ImageView ivPlaymode;
    @BindView(R.id.iv_pre)
    ImageView ivPre;
    @BindView(R.id.iv_play_pause)
    ImageView ivPlayPause;
    @BindView(R.id.iv_next)
    ImageView ivNext;
    @BindView(R.id.iv_list)
    ImageView ivList;
    private ServiceConnection conn;
    private MediaPlayerService.MyBinder myBinder;
    private MyBroadcastReceiver receiver;
    private AnimationDrawable waveAnimation;
    public final int UPDATE_PLAY_DURATION = 100;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                //此处需要常量
                case UPDATE_PLAY_DURATION:
                    Log.e("handleMessage: ","handler");
                    updateTime();
                    break;
            }
        }
    };
    private String tottleTime;

    private void updateTime() {
        int currntDuration = myBinder.getCurrntDuration();
        String time = utils.formateTime(currntDuration);
        tvTime.setText(time + "/" + tottleTime);
        sbProgress.setProgress(currntDuration);
        handler.sendEmptyMessageDelayed(UPDATE_PLAY_DURATION, 500);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.setStatusBarColor(Color.TRANSPARENT);
            //window.setNavigationBarColor(Color.TRANSPARENT);
        }
        setContentView(R.layout.activity_musicplay);
        ButterKnife.bind(this);
        initService();
        initView();

        receiver = new MyBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter("com.mediaplayer.service");
        intentFilter.addAction("pause.play");
        registerReceiver(receiver, intentFilter);


    }

    private void initService() {
        Intent intent = getIntent();
        intent.setClass(getApplication(), MediaPlayerService.class);
        startService(intent);
        conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                //如果bindservice后，service里的bind方法有返回值，就执行这个方法，service参数就是
                myBinder = (MediaPlayerService.MyBinder) service;
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };
        //绑定服务后，拿到服务里的对象开始通信，mybinder就是通信包装。
        bindService(intent, conn, BIND_AUTO_CREATE);
    }

    private void initView() {
        /** 获取状态栏高度
         * */
        int statusBarHeight1 = -1;
        //获取status_bar_height资源的ID
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            //根据资源ID获取响应的尺寸值
            statusBarHeight1 = getResources().getDimensionPixelSize(resourceId);
        }
        //获取状态栏高度 设置到顶部标题栏的顶部外边距
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) rlTop.getLayoutParams();
        layoutParams.topMargin = statusBarHeight1;
        rlTop.setLayoutParams(layoutParams);

        waveAnimation = (AnimationDrawable) ivWave.getDrawable();


    }

    @OnClick({R.id.iv_back,R.id.iv_playmode, R.id.iv_pre, R.id.iv_play_pause, R.id.iv_next, R.id.iv_list})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_playmode:
                MediaPlayerService.currentMode = ++ MediaPlayerService.currentMode%3;
                changeModeIcon();
                break;
            case R.id.iv_pre:
                myBinder.preOrNext(MediaPlayerService.PLAY_Mode_PRE);
                break;
            case R.id.iv_play_pause:
                myBinder.playPause();
                updatePlayIcon();
                break;
            case R.id.iv_next:
                myBinder.preOrNext(MediaPlayerService.PLAY_Mode_NEXT);
                break;
            case R.id.iv_list:
                break;
            case R.id.iv_back:
                finish();
                break;
        }
    }

    private void changeModeIcon() {
        switch (MediaPlayerService.currentMode){
            case MediaPlayerService.MODE_ORDER :
                ivPlaymode.setImageResource(R.drawable.selector_playmode_list);
                break;
            case MediaPlayerService.MODE_SINGLE :
                ivPlaymode.setImageResource(R.drawable.selector_playmode_single);
                break;
            case MediaPlayerService.MODE_RANDOM :
                ivPlaymode.setImageResource(R.drawable.selector_playmode_shuffle);
                break;
        }
        SharedPreferences play_mode = getApplication().getSharedPreferences("mediapaly", 0);
        SharedPreferences.Editor edit = play_mode.edit();
        edit.putInt("mode",MediaPlayerService.currentMode);
        edit.commit();
    }


    private class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("com.mediaplayer.service".equals(action)) {
                initPlayUi();
                updatePlayIcon();
            } else if ("pause.play".equals(action)) {
                stopPlayUi();
            }
        }
    }

    private void stopPlayUi() {
        handler.removeMessages(UPDATE_PLAY_DURATION);
    }

    private void initPlayUi() {
        MusicBean currentMusic = myBinder.getCurrentMusic();
        tvTitle.setText(currentMusic.musicname);
        tvArtist.setText(currentMusic.musicartist);
        tottleTime = utils.formateTime(currentMusic.musiduration);
        tvTime.setText("00:00/" + tottleTime);
        sbProgress.setMax(currentMusic.musiduration);

        sbProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    myBinder.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        handler.sendEmptyMessage(UPDATE_PLAY_DURATION);
    }

    private void updatePlayIcon() {
        if (myBinder.isPlaying()) {
            ivPlayPause.setImageResource(R.drawable.selector_play);
            waveAnimation.start();
        } else {
            ivPlayPause.setImageResource(R.drawable.selector_pause);
            waveAnimation.stop();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (myBinder != null) {
            handler.sendEmptyMessage(UPDATE_PLAY_DURATION);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeMessages(UPDATE_PLAY_DURATION);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //注销服务
        unbindService(conn);
        //注销广播接收者
        unregisterReceiver(receiver);
    }


}
