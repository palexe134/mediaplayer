package com.viedo.mediaplayer.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabSelectListener;
import com.viedo.mediaplayer.R;
import com.viedo.mediaplayer.fragment.VbangFragment;
import com.viedo.mediaplayer.utils.FragmentFactory;
import com.viedo.mediaplayer.utils.utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.main_framelayout)
    FrameLayout mainFramelayout;
    @BindView(R.id.bottomBar)
    BottomBar bottomBar;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initAcitonBar();
        initBottomBar();

    }

    private void initBottomBar() {
        bottomBar.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelected(@IdRes int tabId) {
//               utils.showToast(MainActivity.this,"id:"+tabId);
                switchFragment(tabId);
            }
        });
    }

    private void switchFragment(int tabId) {
        position = -1;
        switch (tabId){
            case R.id.tab_main:
                position =0;
                break;
            case R.id.tab_mv:
                position =1;
                break;
            case R.id.tab_vbang:
                position =2;
                break;
            case R.id.tab_yuedan:
                position =3;
                break;
        }
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        for(int i =0;i<4;i++){
            Fragment fragment = FragmentFactory.getFragment(i);
            if(position ==i){
                if(fragment.isAdded()){
                    transaction.show(fragment);
                }else{
                    transaction.add(R.id.main_framelayout,fragment);
                }
            }else{
                if(fragment.isAdded()){
                    transaction.hide(fragment);
                }
            }
        }
        transaction.commit();

    }


    private void initAcitonBar() {
        toolbar.setTitle("mediaplayer");
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.setting:
                utils.showToast(this, "设置");
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults[0]== PermissionChecker.PERMISSION_GRANTED){
            VbangFragment fragment = (VbangFragment) FragmentFactory.getFragment(position);
            fragment.initData();
        }else{
            utils.showToast(this,"请授权后操作");
        }


    }
}
