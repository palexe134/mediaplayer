package com.viedo.mediaplayer.fragment;

import android.Manifest;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.Audio.Media;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.viedo.mediaplayer.R;
import com.viedo.mediaplayer.activity.MusicPlayerActivity;
import com.viedo.mediaplayer.adapter.MusicAdapter;
import com.viedo.mediaplayer.bean.MusicBean;
import com.viedo.mediaplayer.utils.utils;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.internal.Utils;


/**
 * Created by palexe on 2017/3/20.
 */

public class VbangFragment extends BaseFragment {
    @BindView(R.id.listview)
    ListView listview;
    private MusicAdapter musicAdapter;


    @Override
    public void initView(View view) {
        ButterKnife.bind(this,view);
        musicAdapter = new MusicAdapter(getContext(),null);
        listview.setAdapter(musicAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<MusicBean> musicList = new ArrayList<>();
                Cursor cursor = musicAdapter.getCursor();
                if(cursor!=null) {
                    cursor.moveToPosition(-1);
                    while (cursor.moveToNext()) {
                        MusicBean bean = MusicBean.getMusicBean(cursor);
                        musicList.add(bean);
                    }
                    Intent intent = new Intent(getContext(), MusicPlayerActivity.class);
                    intent.putExtra("position",position);
                    //list已经实现了序列号，intent里可以直接放如序列号的对象
                    intent.putExtra("list",musicList);
                    startActivity(intent);
                }

            }
        });
        if(Build.VERSION.SDK_INT>=23){
            if(ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)==
                    PermissionChecker.PERMISSION_DENIED){
                ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);
            }
            return;
        }
        initData();
    }

    public void initData() {
        ContentResolver contentResolver = getActivity().getApplication().getContentResolver();
        Uri uri = Media.EXTERNAL_CONTENT_URI;
//        Cursor cursor = contentResolver.query(uri, new String[]{
//                Media._ID,
//                Media.DATA,
//                Media.DURATION,
//                Media.TITLE,
//                Media.SIZE,
//                Media.ARTIST
//        }, null, null, null);
//        utils.printCursor(cursor);

        //异步查询，使用该匿名内部类重写回调方法
        new AsyncQueryHandler(contentResolver){
            @Override
            protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
                MusicAdapter m = (MusicAdapter) cookie;
                m.changeCursor(cursor);
            }
        }.startQuery(1,musicAdapter,uri, new String[]{Media._ID,Media.DATA,
                Media.DURATION,
                Media.TITLE,
                Media.SIZE,
                Media.ARTIST
        }, null, null, null);


//        musicAdapter.changeCursor(cursor);


    }

    @Override
    public int getFragmentID() {
        return R.layout.fragment_vbang;
    }



}
