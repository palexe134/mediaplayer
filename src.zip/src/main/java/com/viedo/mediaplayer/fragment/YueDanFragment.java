package com.viedo.mediaplayer.fragment;

import android.view.View;

import com.viedo.mediaplayer.R;

/**
 * Created by palexe on 2017/3/20.
 */

public class YueDanFragment extends BaseFragment {
    @Override
    public void initView(View view) {

    }

    @Override
    public int getFragmentID() {
        return R.layout.fragment_yuedan;
    }
}
