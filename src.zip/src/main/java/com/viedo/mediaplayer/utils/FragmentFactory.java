package com.viedo.mediaplayer.utils;

import android.support.v4.app.Fragment;

import com.viedo.mediaplayer.fragment.BaseFragment;
import com.viedo.mediaplayer.fragment.MVFragment;
import com.viedo.mediaplayer.fragment.MainFragment;
import com.viedo.mediaplayer.fragment.VbangFragment;
import com.viedo.mediaplayer.fragment.YueDanFragment;

import java.util.HashMap;

/**
 * Created by palexe on 2017/3/20.
 */

public class FragmentFactory {
    static HashMap<Integer, BaseFragment> hashMap = new HashMap<>();

    public static Fragment getFragment(int position) {
        BaseFragment fragment = hashMap.get(position);
        if (fragment == null) {
            switch (position) {
                case 0:
                    fragment = new MainFragment();
                    break;
                case 1:
                    fragment = new MVFragment();
                    break;
                case 2:
                    fragment = new VbangFragment();
                    break;
                case 3:
                    fragment = new YueDanFragment();
                    break;
            }
            hashMap.put(position,fragment);
        }
        return fragment;
    }



}
