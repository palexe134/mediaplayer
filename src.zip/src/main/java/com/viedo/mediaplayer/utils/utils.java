package com.viedo.mediaplayer.utils;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by palexe on 2017/1/31.
 */

public class utils {

    private static Toast toast;

    public static void showToast(Context context, String msg) {
        if (toast == null) {

            toast = Toast.makeText(context.getApplicationContext(), msg, Toast.LENGTH_SHORT);
        } else {
            toast.setText(msg);
        }
        toast.show();

    }

    public static void printCursor(Cursor cursor) {
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    Log.e("printCursor: ", cursor.getColumnName(i) + cursor.getString(i));
                }
            }
        }
    }

    public static String formateTime(int time) {
        int h = 60 * 60 * 1000;
        int m = 60 * 1000;
        int s = 1000;
        int hh = time / h;
        int mm = time % h / m;
        int ss = time % m / s;
        String format = "";
        if (hh > 0) {
            format = String.format("%02d:%02d:%02d", hh, mm, ss);
        } else {
            format = String.format("%02d:%02d", mm, ss);
        }
        return format;
    }


}

